export const environment = {
    production: true,
    firebase: {
        apiKey: 'AIzaSyDtJHmw7tpd1NOQ5MsS8Wm1haR6G31R6ts',
        authDomain: 'dabubble-815a4.firebaseapp.com',
        projectId: 'dabubble-815a4',
        storageBucket: 'dabubble-815a4.firebasestorage.app',
        messagingSenderId: '962703875124',
        appId: '1:962703875124:web:17a27f931a976e6fc7fe61',
    },
};