import {
  EnvironmentInjector,
  inject,
  Injectable,
  runInInjectionContext,
} from '@angular/core';
import {
  Firestore,
  collection,
  query,
  orderBy,
  collectionData,
  addDoc,
  serverTimestamp,
  doc,
  updateDoc,
  where,
  getDocs,
  getDoc
} from '@angular/fire/firestore';
import { catchError, combineLatest, EMPTY, map, Observable, of, switchMap, throwError } from 'rxjs';
import { User } from '../../shared/models/user';

import { AuthService } from '../services/auth.service';
import { Auth, authState } from '@angular/fire/auth';
import { FirestoreHelpers } from '../firebase/firestore-helper';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  private fs = inject(Firestore);
  private authService = inject(AuthService);
  private env = inject(EnvironmentInjector);
  private auth = inject(Auth);
  private firestoreHelper = inject(FirestoreHelpers);

  constructor() { }

  /**
   * Checks if a user with the given email exists in the Firestore users collection.
   * Returns true if found, false otherwise.
   */
  async emailExistsInFirestore(email: string): Promise<boolean> {
    const ref = collection(this.fs, 'users');
    const q = query(ref, where('email', '==', email));
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  }
  // ...existing code...

  /**
   * Returns a live stream of all users ordered by `displayName` ascending.
   *
   * Each emission reflects real-time updates from Firestore.
   * The document ID is mapped to the `id` property on each `User`.
   *
   * @returns Observable that emits arrays of `User` documents.
   */
  users$(): Observable<User[]> {
    return this.firestoreHelper.authedCollection$<User>(() => {
      const ref = collection(this.fs, 'users');
      return query(ref, orderBy('displayName', 'asc'));
    }); 
  }

  usersWithCurrentFirst$(): Observable<User[]> {
    return combineLatest([
      this.users$(),
      this.currentUser$()
    ]).pipe(
      map(([users, currentUser]) => {
        if (!currentUser) return users; 

        const currentUid = currentUser.uid;
        const sorted = users.sort((a, b) => a.displayName.localeCompare(b.displayName));
        const index = sorted.findIndex(u => u.uid === currentUid);
        
        if (index > -1) {
          const [current] = sorted.splice(index, 1);
          sorted.unshift(current);
        }

        return sorted;
      })
    );
  }

  /**
   * Returns the current application user as an observable.
   * First it gets the current user-object from the Firebase authentication. If it
   * exist, it queries the users collection in Firestore for a document whose uid field
   * matches the Firebase user's UID.
   *
   * @returns Observable<User | null> — the current user object from Firestore,
   *          or `null` if not authenticated or no matching record is found.
   */
  currentUser$(): Observable<User | null> {
    return runInInjectionContext(this.env, () =>
      authState(this.auth).pipe(
        switchMap(u => {
          if (!u) return of(null);

          return this.firestoreHelper.authedCollection$<User>(() => {
            const ref = collection(this.fs, 'users');
            return query(ref, where('uid', '==', u.uid));
          }).pipe(
            map(users => (users[0] as User) ?? null)
          );
        }),
        catchError(err =>
          err?.code === 'permission-denied' ? of(null) : throwError(() => err)
        ),
      )
    );
  }

  /**
   * Creates a new user document in the `users` collection.
   *
   * Sets `createdAt` and `lastSeenAt` using `serverTimestamp()` so the server
   * determines the time. Add other required fields from your `User` model as needed.
   *
   * @param uid Firebase Authentication UID.
   * @param email Primary email address.
   * @param displayName Human-friendly display name.
   * @param imgUrl Absolute URL for the user's avatar image.
   * @returns Promise that resolves when the document is written.
   */
  async createUser(
    uid: string,
    email: string,
    displayName: string,
    imgUrl: string
  ) {
    const ref = collection(this.fs, 'users');
    await addDoc(ref, {
      uid,
      displayName,
      email,
      imgUrl,
      createdAt: serverTimestamp(),
      lastSeenAt: '',
      status: 'offline',
      updatedAt: serverTimestamp(),
    });
  }

  /**
   * Updates the `displayName` of an existing user document and stamps `updatedAt`.
   *
   * @param userId Firestore document ID of the user (i.e., `users/{userId}`).
   * @param displayName New display name to persist.
   * @returns Promise that resolves when the update completes.
   */
  async updateDisplayName(userId: string, displayName: string) {
    return runInInjectionContext(this.env, async () => {
      const ref = doc(this.fs, `users/${userId}`);
      await updateDoc(ref, {
        displayName: displayName,
        updatedAt: serverTimestamp(),
      });
    });
  }

  /**
   * Updates the `imgUrl` (avatar) of an existing user document and stamps `updatedAt`.
   *
   * @param userId Firestore document ID of the user (i.e., `users/{userId}`).
   * @param imgUrl New absolute URL for the avatar image.
   * @returns Promise that resolves when the update completes.
   */
  async updateImgUrl(userId: string, imgUrl: string) {
    return runInInjectionContext(this.env, async () => {
      const ref = doc(this.fs, `users/${userId}`);
      await updateDoc(ref, {
        imgUrl: imgUrl,
        updatedAt: serverTimestamp()
      });
    });
  }

  /**
 * Gets a single user by document ID from Firestore
 */
  async getUserById(userId: string): Promise<User | null> {
    return runInInjectionContext(this.env, async () => {
      try {
        const userRef = doc(this.fs, 'users', userId);
        const userSnap = await getDoc(userRef);

        if (userSnap.exists()) {
          return { id: userSnap.id, ...userSnap.data() } as User;
        }
        return null;
      } catch (error) {
        console.error('Error fetching user by ID:', error);
        return null;
      }
    });
  }
}
