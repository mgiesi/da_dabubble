import { Component, inject, OnInit } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProfileMenuComponent } from './features/profile/profile-menu/profile-menu.component';
import { AuthService } from './core/services/auth.service';
import { SharedFunctionsService } from '../../src/app/core/services/shared-functions.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, ProfileMenuComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  title = 'DABubble';
  private auth = inject(AuthService);
  private sharedFunctions = inject(SharedFunctionsService);
  isAuthenticated$ = this.auth.isAuthenticated$;
  showAnimation$ = this.sharedFunctions.showAnimation$;

private router = inject(Router);
  currentView: 'workspace' | 'chat' | 'thread' = 'workspace';

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // Prüfe URL um View zu bestimmen
        if (event.url.includes('/chat')) {
          this.currentView = 'chat';
        } else {
          this.currentView = 'workspace';
        }
      }
    });
  }
}
