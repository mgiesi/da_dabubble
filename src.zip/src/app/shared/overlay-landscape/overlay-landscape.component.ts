import { Component } from '@angular/core';

@Component({
  selector: 'app-overlay-landscape',
  imports: [],
  templateUrl: './overlay-landscape.component.html',
  styleUrl: './overlay-landscape.component.scss'
})
export class OverlayLandscapeComponent {

}
